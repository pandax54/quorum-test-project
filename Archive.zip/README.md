# Project setup and Execution:

To build and run the Docker container using Docker Compose, execute the following command in the terminal:

```
$ docker-compose -f docker-compose.yml up --build
```

The container will be accessible at http://localhost:8000 once running
